package com.cg.dao;

import java.util.HashMap;

import com.cg.bean.Customer;

public class CustomerDaoImpl implements CustomerDao{
	
	private static HashMap<Integer, Customer> lnmap = new HashMap<Integer, Customer>();

	@Override
	public void applyLoan(Customer loan) {
		lnmap.put(loan.getAcntNo(), loan);
	}

	@Override
	public Customer getByAcntNo(int acnt) {
		return lnmap.get(acnt);
	}

	@Override
	public HashMap<Integer, Customer> txnsDetail() {
		return lnmap;
	}


}
