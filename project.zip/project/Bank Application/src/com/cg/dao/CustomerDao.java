package com.cg.dao;

import java.util.HashMap;

import com.cg.bean.Customer;

public interface CustomerDao {
	
	public void applyLoan(Customer loan);

	public HashMap<Integer, Customer> txnsDetail();

	public Customer getByAcntNo(int actno);


}
