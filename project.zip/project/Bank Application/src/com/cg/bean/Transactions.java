/**
 * @author Pradeepthi 
 */
package com.cg.bean;

public class Transactions {

	private double amount;
	private int acntNo;
	private double balance;
    
	/*
	 * Default Constructor
	 */
	
	public Transactions() {

	}
	
	/*
	 * Constructor using fields
	 */

	public Transactions(double amount, double balance, int acntNo) {
		this.amount = amount;
		this.acntNo = acntNo;
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "amount=" + amount + " balance=" + balance;
	}

}
