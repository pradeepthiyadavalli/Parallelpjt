
/**
 * @author Pradeepthi
 *
 */
package com.cg.bean;

import java.util.ArrayList;

public class Customer {
	private int acntNo;
	private String name;
	private int period;
	private double balance;
	private int loanType;
	private double emi;

	/*
	 * Default Constructor
	 */

	public Customer() {

	}

	/*
	 * Constructor using fields
	 */

	public Customer(String name, int loanType, int period) {
		super();
		this.name = name;
		this.period = period;
		this.loanType = loanType;
		
	}

	private ArrayList<Transactions> txns;

	/*
	 * Getters and Setters and toString method
	 */
	public ArrayList<Transactions> getTxns() {
		return txns;
	}

	public void setTxns(ArrayList<Transactions> txns) {
		this.txns = txns;
	}

	public int getLoanType() {
		return loanType;
	}

	public void setLoanType(int loanType) {
		this.loanType = loanType;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public int getAcntNo() {
		return acntNo;
	}

	public void setAcntNo(int acntNo) {
		this.acntNo = acntNo;
		this.txns = new ArrayList<>();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPeriod() {
		return period;
	}

	public void setPeriod(int period) {
		this.period = period;
	}

	public double getEmi() {
		return emi;
	}

	public void setEmi(double emi) {
		this.emi = emi;
	}

	@Override
	public String toString() {
		return "Loan [acntNo=" + acntNo + ", name=" + name + ", period=" + period + ", balance=" + balance
				+ ", loanType=" + loanType + "]";
	}

}
