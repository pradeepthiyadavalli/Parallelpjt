package com.cg.ui;

import java.util.Scanner;

import com.cg.bean.Customer;
import com.cg.exception.CustomerException;
import com.cg.service.CustomerService;
import com.cg.service.CustomerServiceImpl;

public class CustomerClient {

	public static void main(String[] args) throws CustomerException {

		Scanner sc = new Scanner(System.in);
		CustomerService cs = new CustomerServiceImpl();
		int choice, acnt;

		do {

			System.out.println(
					"1:ApplyLoan \n2:ShowBalance \n3:PayEmi \n4:CalculateEMI \n5:ForeClose \n6:PrintTransactions \n7:Exit");
			System.out.println("Enter your Choice:");
			choice = sc.nextInt();

			switch (choice) {

			case 1:
				String name;
				int loanType;
				double amount;
				Customer cust = new Customer();
				do {
					System.out.println("Enter your name:");
					name = sc.next();
					if (cs.isValidateName(name) == true)
						break;
					else
						System.out.println("Invalid Name");
				} while (true);
				System.out.println("Enter amount");
				amount = sc.nextDouble();
				do {
					System.out.println("Types of loans: \n1(HomeLoan Loan)=20%, \n2(Car Loan=15%), \n3(Student Loan)=10%");
					loanType = sc.nextInt();
					if (cs.isValidateLoantype(loanType) == true)
						break;
					else
						System.out.println("Invalid LoanType");
				} while (true);
				System.out.println("Enter period of time");
				int period = sc.nextInt();
				cust = new Customer(name, loanType, period);
				cust.setBalance(amount);
				cs.applyLoan(cust);
				System.out.println("Welcome " + name + " your Account Number is " + cust.getAcntNo());
				break;

			case 2:
				System.out.println("Enter A/C No");
				acnt = sc.nextInt();
				if(cs.getLoanDetails(acnt) != null)
					System.out.println("Your Balance is " + cs.getLoanDetails(acnt).getBalance());
				else
					throw new CustomerException("Account number not found");
				break;

			case 3:
				System.out.println("Enter A/C No");
				acnt = sc.nextInt();
				if(cs.getLoanDetails(acnt) != null) {
					System.out.println(cs.getLoanDetails(acnt).getName() + " have paid " + cs.payEmi(acnt));
					System.out.println("Remaining balance is " + cs.getLoanDetails(acnt).getBalance());
				}
				else
					throw new CustomerException("Account number not found");
				break;

			case 4:
				System.out.println("Enter A/C No");
				acnt = sc.nextInt();
				double emi = cs.calculateEmi(cs.getLoanDetails(acnt).getBalance(), cs.getLoanDetails(acnt).getPeriod(),
						cs.getLoanDetails(acnt).getLoanType());
				System.out.println(cs.getLoanDetails(acnt).getName() + " has to pay EMI is " + emi);
				break;

			case 5:
				System.out.println("Enter A/C No");
				acnt = sc.nextInt();
				cs.forclose(acnt);
				System.out.println("You have payed the whole amount successfully and your account is Closed");
				break;

			case 6:
				System.out.println("Enter A/C No");
				acnt = sc.nextInt();
				cs.showTransaction(acnt);
				break;

			case 7:
				System.out.println("Exit");
				break;

			default:
				System.out.println("Enter Correct Choice");
			}

		} while (choice != 7);

	}

}
