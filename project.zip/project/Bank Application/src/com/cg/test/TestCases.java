package com.cg.test;

import static org.junit.Assert.assertEquals;


import org.junit.Before;
import org.junit.Test;


import com.cg.service.CustomerServiceImpl;

public class TestCases {

	CustomerServiceImpl service;

	@Before
	public void init() {
		service = new CustomerServiceImpl();
	}

	/*
	 * To Test Name
	 */
	@Test
	public void testIsNameValid() {
		assertEquals(true, service.isValidateName("Pradeepthi"));
	}

	/*
	 * To Test Name
	 */
	@Test
	public void testIsLoanTypeValid() {
		assertEquals(true, service.isValidateLoantype(1));
	}

}
