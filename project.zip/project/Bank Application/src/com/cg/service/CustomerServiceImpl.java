package com.cg.service;

import java.util.ArrayList;
import java.util.HashMap;

import com.cg.bean.Customer;
import com.cg.bean.Transactions;
import com.cg.dao.CustomerDaoImpl;
import com.cg.exception.CustomerException;

public class CustomerServiceImpl implements CustomerService {

	CustomerDaoImpl dao = new CustomerDaoImpl();

	/*
	 * To save/applyLoan
	 */
	@Override
	public void applyLoan(Customer loan) {
		int acnt = (int) (Math.random() * 10000);
		loan.setAcntNo(acnt);
		dao.applyLoan(loan);
	}

	/*
	 * To Calculate EMI
	 */
	@Override
	public double calculateEmi(double balance, int time, int loanType) {
		double rate = (double) (typeOfLoan(loanType));
		int period = time * 12;
		double emi = (balance * (rate / 1200) * Math.pow(1 + (rate / 1200), period))
				/ (Math.pow(1 + (rate / 1200), period) - 1);
		return (int) emi;
	}

	/*
	 * To get details
	 */
	@Override
	public Customer getLoanDetails(int acntNo) {
		return dao.getByAcntNo(acntNo);
	}

	/*
	 * To get loanType
	 */
	@Override
	public int typeOfLoan(int loanType) {
		int r = 0;
		if (1 == (loanType))
			r = 10;
		else if (2 == (loanType))
			r = 15;
		else if (3 == (loanType))
			r = 5;
		return r;
	}

	/*
	 * To show transactions
	 */
	@Override
	public void showTransaction(int acnt) throws CustomerException {
		ArrayList<Transactions> txns;
		if ((dao.getByAcntNo(acnt)) != null) {
			txns = dao.getByAcntNo(acnt).getTxns();
			System.out.println("Payed Amount");
			for (int i = 0; i < txns.size(); i++) {
				System.out.println(txns.get(i));
			}

		} else {
			throw new CustomerException("Account number not found");
		}
	}

	/*
	 * To pay EMI
	 */
	@Override
	public double payEmi(int acnt) throws CustomerException {
		Transactions txn = new Transactions();
		double balance = dao.getByAcntNo(acnt).getBalance();
		int period = dao.getByAcntNo(acnt).getPeriod();
		int loanType = dao.getByAcntNo(acnt).getLoanType();
		double amount = calculateEmi(balance, period, loanType);
		balance = dao.getByAcntNo(acnt).getBalance() - amount;
		dao.getByAcntNo(acnt).setBalance(balance);

		ArrayList<Transactions> txns = dao.getByAcntNo(acnt).getTxns();
		txn = new Transactions(amount, balance, acnt);
		txns.add(txn);
		dao.getByAcntNo(acnt).setTxns(txns);
		return amount;

	}

	/*
	 * To foreclose Account
	 */
	@Override
	public void forclose(int acnt) throws CustomerException {
		Transactions txn = new Transactions();
		double balance;
		if ((dao.getByAcntNo(acnt)) != null) {
			double amount = dao.getByAcntNo(acnt).getBalance();
			ArrayList<Transactions> txns;
			txns = dao.getByAcntNo(acnt).getTxns();
			balance = 0;
			dao.getByAcntNo(acnt).setBalance(balance);
			txn = new Transactions(amount, balance, acnt);
			txns.add(txn);
			dao.getByAcntNo(acnt).setTxns(txns);
		} else {
			throw new CustomerException("�ccount number not found");
		}
	}

	/*
	 * transaction details
	 */
	@Override
	public HashMap<Integer, Customer> txnsDetail() {
		return dao.txnsDetail();
	}

	/*
	 * To validate Name
	 */
	public boolean isValidateName(String name) {
		String pattern = "[A-Za-z]{4,}";
		return name.matches(pattern);
	}

	/*
	 * To validate loanTYpe
	 */
	@Override
	public boolean isValidateLoantype(int loanType) {
		String pattern = "[1-3] {1}";
		return (loanType + " ").matches(pattern);
	}

}
