package com.cg.service;

import java.util.HashMap;

import com.cg.bean.Customer;
import com.cg.exception.CustomerException;

public interface CustomerService {

	public void applyLoan(Customer loan);

	public double calculateEmi(double amount, int time, int loanType);

	public Customer getLoanDetails(int acnt);

	public int typeOfLoan(int loanType);

	public HashMap<Integer, Customer> txnsDetail();

	public void showTransaction(int accnt) throws CustomerException;

	public double payEmi(int acnt) throws CustomerException;

	public void forclose(int acnt) throws CustomerException;

	public boolean isValidateName(String name);

	public boolean isValidateLoantype(int loanType);

}
