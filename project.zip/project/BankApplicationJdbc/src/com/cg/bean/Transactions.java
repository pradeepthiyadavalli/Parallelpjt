package com.cg.bean;

public class Transactions {
	
	private double amount;
	private int acntNo;
	private double balance;
	
	public Transactions() {

	}

	public Transactions(double amount, double balance, int acntNo) {
		this.amount = amount;
		this.acntNo = acntNo;
		this.balance = balance;
	}
	

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public int getAcntNo() {
		return acntNo;
	}

	public void setAcntNo(int acntNo) {
		this.acntNo = acntNo;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "amount=" + amount + " balance=" + balance ;
	}


}
