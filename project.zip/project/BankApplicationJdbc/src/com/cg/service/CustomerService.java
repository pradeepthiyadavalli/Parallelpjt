package com.cg.service;

import java.util.HashMap;
import java.util.List;

import com.cg.bean.Customer;
import com.cg.bean.Transactions;

public interface CustomerService {

	public void applyLoan(Customer loan);

	public double calculateEmi(double amount, int time, int loanType);

	public Customer getLoanDetails(int acnt);

	public int typeOfLoan(int loanType);

	//public HashMap<Integer, Customer> txnsDetail();

	public void showTransaction(int accnt);

	public double payEmi(int acnt);

	public void forclose(int acnt);

	List<Transactions> printTransactions(int acnt);

}
