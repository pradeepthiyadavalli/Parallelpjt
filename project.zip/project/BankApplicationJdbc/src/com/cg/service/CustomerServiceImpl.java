package com.cg.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cg.bean.Customer;
import com.cg.bean.Transactions;
import com.cg.dao.CustomerDaoImpl;

public class CustomerServiceImpl implements CustomerService {

	CustomerDaoImpl dao = new CustomerDaoImpl();

	@Override
	public void applyLoan(Customer loan) {
		int acnt = (int) (Math.random() * 100000);
		loan.setAcntNo(acnt);
		dao.applyLoan(loan);
	}

	@Override
	public double calculateEmi(double balance, int time, int loanType) {
		double rate = (double) (typeOfLoan(loanType));
		int period = time * 12;
		double emi = (balance * (rate / 1200) * Math.pow(1 + (rate / 1200), period))
				/ (Math.pow(1 + (rate / 1200), period) - 1);
		return (int) emi;
	}

	@Override
	public Customer getLoanDetails(int acntNo) {
		return dao.getByAcntNo(acntNo);
	}

	@Override
	public int typeOfLoan(int loanType) {
		int r = 0;
		if (101 == (loanType))
			r = 10;
		else if (102 == (loanType))
			r = 15;
		else if (103 == (loanType))
			r = 5;
		return r;
	}

	@Override
	public void showTransaction(int acnt) {
		ArrayList<Transactions> txns = dao.getByAcntNo(acnt).getTxns();
		System.out.println("Payed Amount");
		for (int i = 0; i < txns.size(); i++) {
			System.out.println(txns.get(i));
		}
	}

	@Override
	public double payEmi(int acnt) {
		Transactions txn = new Transactions();
		double balance = dao.getByAcntNo(acnt).getBalance();
		int period = dao.getByAcntNo(acnt).getPeriod();
		int loanType = dao.getByAcntNo(acnt).getLoanType();
		double amount = calculateEmi(balance, period, loanType);

		balance = dao.getByAcntNo(acnt).getBalance() - amount;
//		dao.getByAcntNo(acnt).setBalance(balance);
		dao.updateBalance(acnt,balance);
		
		ArrayList<Transactions> txns = dao.getByAcntNo(acnt).getTxns();
		txn = new Transactions(amount, balance, acnt);
		dao.insertTransactions(txn);
		dao.getByAcntNo(acnt).setTxns(txns);
		return amount;
	}

	@Override
	public void forclose(int acnt) {
		Transactions txn = new Transactions();
		double balance;
		double amount = dao.getByAcntNo(acnt).getBalance();
		ArrayList<Transactions> txns = dao.getByAcntNo(acnt).getTxns();
		balance = 0;
		dao.getByAcntNo(acnt).setBalance(balance);
		txn = new Transactions(amount, balance, acnt);
		dao.insertTransactions(txn);
		dao.getByAcntNo(acnt).setTxns(txns);
	}

	@Override
	public List<Transactions> printTransactions(int acnt) {
		return dao.printTransactions(acnt);	
	}

}
