package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cg.bean.Customer;
import com.cg.bean.Transactions;
import com.cg.util.JdbcFactory;

public class CustomerDaoImpl implements CustomerDao {

	@Override
	public boolean applyLoan(Customer loan) {
		String sql = "insert into cust values(?,?,?,?,?,?)";
		Connection conn = null;
		
		try {
			conn = JdbcFactory.getConnection();
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setInt(1, loan.getAcntNo());
			stmt.setString(2, loan.getName());
			stmt.setDouble(3, loan.getBalance());
			stmt.setInt(4, loan.getLoanType());
			stmt.setInt(5, loan.getPeriod());
			stmt.setDouble(6,loan.getEmi());
			stmt.executeUpdate();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} finally {
			if(conn != null)
				try{
					conn.close();
				} catch (SQLException e){
					e.printStackTrace();
				}
		}
		
		
	}

	@Override
	public Customer getByAcntNo(int acnt) {
		String sql = "select * from cust where acntNo=?";
		Connection conn = null;
		Customer loan = null;
		
		try {
			conn = JdbcFactory.getConnection();
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setInt(1, acnt); 
			ResultSet rs = stmt.executeQuery();
			
			if(rs.next()) {
				loan = new Customer();
				loan.setAcntNo(rs.getInt(1));
				loan.setName(rs.getString(2));
				loan.setBalance(rs.getDouble(3));
				loan.setLoanType(rs.getInt(4));	
				loan.setPeriod(rs.getInt(5));
				loan.setEmi(rs.getDouble(6));
			}
			return loan;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} finally {
			if(conn != null)
				try{
					conn.close();
				} catch (SQLException e){
					e.printStackTrace();
				}			
		}
	}
	
	@Override
	public void updateBalance(int acnt, double balance) {
		String sql="update cust set balance=? where acntNo=?";
		Connection conn=null;

		try {
			conn = JdbcFactory.getConnection();
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setDouble(1,balance );
			stmt.setInt(2, acnt);
			stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			if (conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
	
	}
	
	@Override
	public List<Transactions> printTransactions(int acnt) {
		
		String sql="select * from custtxns where acntNo="+acnt;
		Connection conn=null;
		Transactions transaction=null;
		List<Transactions> transactions =new ArrayList<>();
		
		try {
			conn = JdbcFactory.getConnection();
			
			ResultSet rs = conn.createStatement().executeQuery(sql);

			while(rs.next()) {
				
			  transaction=new Transactions();
			  transaction.setAcntNo(rs.getInt(1));
			  transaction.setAmount(rs.getDouble(2));
			  transaction.setBalance(rs.getDouble(3));
				transactions.add(transaction);
			}
			return transactions;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}finally{
			if (conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
			
	}


	@Override
	public void insertTransactions(Transactions transaction) {
		String sql = "insert into custtxns values(?,?,?)";
		Connection conn = null;
		try {
			conn = JdbcFactory.getConnection();
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setInt(1, transaction.getAcntNo());
			stmt.setDouble(2, transaction.getAmount());
			stmt.setDouble(3, transaction.getBalance());
			
			stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

}