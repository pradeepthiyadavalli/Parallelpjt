package com.cg.dao;

import java.util.HashMap;
import java.util.List;

import com.cg.bean.Customer;
import com.cg.bean.Transactions;

public interface CustomerDao {

	public void insertTransactions(Transactions transaction);

	public Customer getByAcntNo(int acnt);

	boolean applyLoan(Customer loan);

	void updateBalance(int acnt, double balance);

	List<Transactions> printTransactions(int acnt);


}
