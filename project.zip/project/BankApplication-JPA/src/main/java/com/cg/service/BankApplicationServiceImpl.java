package com.cg.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.repo.BankApplicationDaoImpl;
import com.cg.entity.BankApplication;
import com.cg.entity.Transactions;

public class BankApplicationServiceImpl implements BankApplicationService {

	private BankApplicationDaoImpl dao;
	Transactions transaction;
	ArrayList<Transactions> list;

	public BankApplicationServiceImpl() {

		list = new ArrayList<>();
		dao = new BankApplicationDaoImpl();
	}

	public int saveLoan(BankApplication loan) {
		int transId = (int) (Math.random() * 1000);
		loan.setTransId(transId);
		dao.beginTransaction();
		double amt = loan.getLoanAmount() + (calculateEmi(loan) * loan.getPeriod());
		calculateEmi(loan);
		loan.setLoanAmount(amt);
		loan.setBalance(amt);
		dao.saveLoan(loan);
		dao.commitTransaction();
		return transId;
	}

	public BankApplication showBalance(int transId) {

		return dao.showBalance(transId);
	}

	public double payEmi(BankApplication loan) {
		dao.beginTransaction();
		double amount = dao.showBalance(loan.getTransId()).getLoanAmount();
		double balance = (dao.showBalance(loan.getTransId()).getBalance()
				- dao.showBalance(loan.getTransId()).getEmi());
		dao.showBalance(loan.getTransId()).setBalance(balance);
		transaction = new Transactions(loan.getTransId(), amount, balance);
		list.add(transaction);
		dao.insertTransactions(transaction);
		dao.updateBalance(loan);
		dao.commitTransaction();
		return balance;
	}

	public BankApplication getDetail(int transId) {
		return dao.getByAcntNo(transId);
	}

	public void foreClose(int transId) {
		dao.beginTransaction();
		Transactions transaction = new Transactions();
		double amount = dao.showBalance(transId).getLoanAmount();
//		double balance=0;
//		dao.showBalance(transId).setBalance(balance);
		transaction = new Transactions(transId, amount, 0);
		list.add(transaction);
		dao.insertTransactions(transaction);
		// dao.updateBalance(transId,balance);
		dao.commitTransaction();
	}

	public double calculateEmi(BankApplication loan) {
		double amt = loan.getLoanAmount();
		double interest = (loan.getRate()) / (12 * 100);

		double period = (loan.getPeriod()) * 12;

		double emi = (amt * interest * (Math.pow(1 + interest, period))) / ((Math.pow(1 + interest, period)) - 1);
		loan.setEmi(emi);
		return emi;
	}

	public List<Transactions> printTransactions(int transId) {

		return dao.printTransactions(transId);
	}

//validations
	public boolean isValidateName(String custName) {
		String pattern = "[A-Za-z]{4,}";
		return custName.matches(pattern);
	}

}
