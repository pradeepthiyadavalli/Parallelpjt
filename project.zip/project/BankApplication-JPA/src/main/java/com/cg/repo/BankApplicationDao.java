package com.cg.repo;

import java.util.List;

import com.cg.entity.BankApplication;
import com.cg.entity.Transactions;

public interface BankApplicationDao {

	void saveLoan(BankApplication loan);

	public BankApplication showBalance(int transId);

	List<Transactions> printTransactions(int transId);

	public void updateBalance(BankApplication loan);

	public void insertTransactions(Transactions transaction);

	void beginTransaction();

	void commitTransaction();

}
