package com.cg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "transaction")
public class Transactions {

	@Id
	@GeneratedValue
	private int Id;
	private int transId;
	@Column(name = "Amount", length = 15)
	private double amount;
	@Column(name = "Balance", length = 15)
	private double balance;

	public Transactions(int transId, double amount, double balance) {
		this.transId = transId;
		this.amount = amount;
		this.balance = balance;
	}

	public Transactions() {
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public int getTransId() {
		return transId;
	}

	public void setTransId(int transId) {
		this.transId = transId;
	}

	@Override
	public String toString() {
		return "Transactions [amount=" + amount + ", balance=" + balance + "]";
	}
}
