package com.cg.repo;

import java.util.List;

import javax.persistence.EntityManager;

import com.cg.entity.BankApplication;
import com.cg.entity.Transactions;

public class BankApplicationDaoImpl implements BankApplicationDao {

	private EntityManager entityManager;

	public BankApplicationDaoImpl() {
		entityManager = JPAUtil.getEntityManager();
	}

	public void saveLoan(BankApplication loan) {

		entityManager.persist(loan);

	}

	public BankApplication getByAcntNo(int transId) {
		return entityManager.find(BankApplication.class, transId);
	}

	public BankApplication showBalance(int transId) {

		BankApplication loan = entityManager.find(BankApplication.class, transId);
		return loan;
	}

	public List<Transactions> printTransactions(int transId) {

		List<Transactions> transactions = entityManager.createQuery("from Transactions where transId=" + transId)
				.getResultList();
		return transactions;

	}

	public void updateBalance(BankApplication loan) {
		entityManager.merge(loan);
	}

	public void insertTransactions(Transactions transaction) {

		entityManager.persist(transaction);
	}

	public void beginTransaction() {
		entityManager.getTransaction().begin();
	}

	public void commitTransaction() {
		entityManager.getTransaction().commit();
	}

}
