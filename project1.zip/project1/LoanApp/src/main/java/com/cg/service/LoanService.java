package com.cg.service;

import java.util.List;


import com.cg.entity.Loan;


public interface LoanService {
	
	public boolean applyLoan(Loan loan);
	
	public Loan showBalance(int accNo) ;
	
	public Loan payEmi(int accNo);
	
	public String foreclose(int accNo) ;
	
	public double calculateEmi(double loanAmount, double interestRate, int timeSpan);
	
	public List<Loan> printTransactions();

}
