package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import com.cg.entity.Loan;
import com.cg.repo.LoanRepo;
@Service
@Transactional
public class LoanServiceImpl implements LoanService{
	@Autowired
	private LoanRepo repo;
	
	@Override
	public boolean applyLoan(Loan loan) {
		double balance=
				(calculateEmi(loan.getLoanAmount(),loan.getInterestRate(),loan.getTimeSpan())*loan.getTimeSpan()*(12));
		loan.setBalance(balance);
		repo.save(loan);
		return true;	
	}

	@Override
	public Loan showBalance(int accNo) {
		System.out.println("Invoking Find Product By Id :"+accNo);
		Loan io =repo.findById(accNo).get();
		return io;
	}

	@Override
	public Loan payEmi(int accNo) {
		System.out.println("Balance updated after paying emi");
		Loan loan = repo.findById(accNo).get();
		repo.save(loan);
		return repo.findById(accNo).get();
	}

	@Override
	public String foreclose(int accNo) {
		return null;
	}

	@Override
	public double calculateEmi(double loanAmount, double interestRate, int timeSpan) {
		interestRate = interestRate / (12 * 100);
		double emi = (loanAmount * interestRate * Math.pow(1 + interestRate, timeSpan))
				/ (Math.pow(1 + interestRate, timeSpan) - 1);
		return emi;
	}

	@Override
	public List<Loan> printTransactions() {
		return repo.findAll();
	}

}
