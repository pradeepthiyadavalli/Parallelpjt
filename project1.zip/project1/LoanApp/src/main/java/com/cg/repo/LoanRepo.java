package com.cg.repo;

import org.springframework.data.jpa.repository.JpaRepository;


import com.cg.entity.Loan;

public interface LoanRepo extends JpaRepository<Loan , Integer> {

}
