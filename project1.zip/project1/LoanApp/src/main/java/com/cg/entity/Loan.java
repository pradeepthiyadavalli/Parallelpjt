package com.cg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Loan_Rest1")
public class Loan {
	@Id
	@Column(name = "AccNo", length = 30)

	private int accNo;
	@Column(name = "Name", length = 30)
	private String name;

	@Column(name = "age", length = 30)
	private int age;

	@Column(name = "loanAmount", length = 30)
	private double loanAmount;
	@Column(name = "interstRate", length = 30)
	private double interestRate = 10;
	@Column(name = "time", length = 30)
	private int timeSpan;
	@Column(name = "balance", length = 30)
	private double balance;

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public Loan() {

	}

	public int getAccNo() {
		return accNo;
	}

	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public double getLoanAmount() {
		return loanAmount;
	}

	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}

	public double getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(double interestRate) {
		this.interestRate = interestRate;
	}

	public int getTimeSpan() {
		return timeSpan;
	}

	public void setTimeSpan(int timeSpan) {
		this.timeSpan = timeSpan;
	}

}