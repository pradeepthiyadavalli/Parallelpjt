package com.cg.exception;


public class NoImportOrderFoundException extends RuntimeException {
	
	private static final long serialVersionUID = 1L;
	//Exception class to handle exceptions when ImportOrder record is not found
	public NoImportOrderFoundException(int id) {
		super("No Order Found with ID: "+id+" in the database.");
		// TODO Auto-generated constructor stub
	}

}