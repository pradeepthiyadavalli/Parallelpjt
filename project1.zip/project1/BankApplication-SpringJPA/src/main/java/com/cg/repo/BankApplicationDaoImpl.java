package com.cg.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.BankApplication;
import com.cg.entity.Transactions;

@Repository
public class BankApplicationDaoImpl implements BankApplicationDao {
	@PersistenceContext
	private EntityManager entityManager;

	@Transactional
	public void saveLoan(BankApplication loan) {
		entityManager.persist(loan);
	}

	public BankApplication showBalance(int transId) {
		BankApplication loan = entityManager.find(BankApplication.class, transId);
		return loan;
	}

	public List<Transactions> printTransactions(int transId) {
		List<Transactions> transactions = entityManager.createQuery("from Transactions where transId=" + transId)
				.getResultList();
		return transactions;
	}

	@Transactional
	public void updateBalance(BankApplication loan) {
		entityManager.merge(loan);
	}

	@Transactional
	public void insertTransactions(Transactions transaction) {
		entityManager.persist(transaction);
	}

}
