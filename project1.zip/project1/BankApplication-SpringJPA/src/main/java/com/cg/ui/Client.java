package com.cg.ui;

import java.util.Scanner;

import com.cg.entity.BankApplication;
import com.cg.service.BankApplicationServiceImpl;

public class Client {
	BankApplication loan;
	BankApplicationServiceImpl service = new BankApplicationServiceImpl();
	Scanner sc = new Scanner(System.in);
	int acntNo;
	String name;
	int transId;
	double loanAmount;
	int period;
	double rate;
	double balance;

	public void BankApplication() {
		
		System.out.println("Enter your AccountNo:");
		acntNo = sc.nextInt();
		do {
			System.out.println("Enter your name:");
			name = sc.next();
			if (service.isValidateName(name) == true)
				break;
			else
				System.out.println("Invalid Name");
		} while (true);

		System.out.println("Enter Loan Amount");
		double loanAmount = sc.nextDouble();
		System.out.println("Enter period");
		period = sc.nextInt();
		System.out.println("Enter Rate of Interest");
		rate = sc.nextDouble();
		int transId = service.saveLoan(new BankApplication(acntNo, name, loanAmount, period, rate));
		System.out.println("Successfully stored with Id:" + transId);
	}

	public void print() {
		System.out.println("Enter Id:");
		int transId = sc.nextInt();
		System.out.println(service.showBalance(transId));
	}

	public void pay() {
		System.out.println("Enter Id:");
		transId = sc.nextInt();
		System.out.println(service.payEmi(transId));

	}

	public void calculateEmi() {
		System.out.println("Enter Id:");
		int transId = sc.nextInt();
		System.out.println(service.showBalance(transId));
	}

	public void foreclose() {
		System.out.println("Enter your Id:");
		transId = sc.nextInt();
		service.foreClose(transId);
	}

	public void printTransaction() {
		System.out.println("Enter Id:");
		transId = sc.nextInt();
		System.out.println(service.printTransactions(transId));
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int ch;
		Client user = new Client();
		do {
			System.out.println("Menu" + "\n" + "1 Apply Loan" + "\n" + "2. Show Balance" + "\n" + "3.Pay EMI" + "\n"
					+ "4 ForeClose Loan" + "\n" + "5.Calculate EMI" + "\n" + "6.Print Transactions" + "\n" + "7.exit");
			System.out.println("Enter your choice");
			ch = sc.nextInt();

			switch (ch) {
			case 1:
				user.BankApplication();
				break;
			case 2:
				user.print();
				break;
			case 3:
				user.pay();
				break;
			case 4:
				user.foreclose();
				break;
			case 5:
				user.calculateEmi();
				break;
			case 6:
				user.printTransaction();
				break;
			case 7:
				System.out.println("END");
				break;

			default:
				System.out.println("Enter the correct choice:");
				break;

			}
		} while (ch != 7);
	}
}
