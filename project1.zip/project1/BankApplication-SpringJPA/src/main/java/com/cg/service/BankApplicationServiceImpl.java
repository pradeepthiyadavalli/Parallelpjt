package com.cg.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.repo.BankApplicationDao;
import com.cg.entity.BankApplication;
import com.cg.entity.Transactions;

public class BankApplicationServiceImpl implements BankApplicationService {

	private BankApplicationDao dao;
	Transactions transaction;
	ArrayList<Transactions> list;

	public BankApplicationServiceImpl() {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("appctx.xml");
		dao = ctx.getBean(BankApplicationDao.class);
		list = new ArrayList<Transactions>();
	}

	public int saveLoan(BankApplication loan) {
		int transId = (int) (Math.random() * 1000);
		loan.setTransId(transId);
		double amt = loan.getLoanAmount() + (calculateEmi(loan) * loan.getPeriod());
		loan.setEmi(calculateEmi(loan));
		loan.setLoanAmount(amt);
		loan.setBalance(amt);
		dao.saveLoan(loan);
		return transId;
	}

	// Method for show balance
	public BankApplication showBalance(int transId) {
		return dao.showBalance(transId);
	}

	// Method for paying emi
	public double payEmi(int transId) {
		double amount = dao.showBalance(transId).getLoanAmount();
		double balance = (dao.showBalance(transId).getBalance() - dao.showBalance(transId).getEmi());
		BankApplication loan = dao.showBalance(transId);
		loan.setBalance(balance);
		transaction = new Transactions(transId, amount, balance);
		list.add(transaction);
		dao.insertTransactions(transaction);
		dao.updateBalance(loan);
		return balance;
	}

	// Method for paying whole amount and closing account
	public void foreClose(int transId) {
		Transactions transaction = new Transactions();
		double amount = dao.showBalance(transId).getLoanAmount();
		transaction = new Transactions(transId, amount, 0);
		list.add(transaction);
		dao.insertTransactions(transaction);
	}

	public double calculateEmi(BankApplication loan) {
		double amt = loan.getLoanAmount();
		double interest = (loan.getRate()) / (12 * 100);
		double period = (loan.getPeriod()) * 12;
		double emi = (amt * interest * (Math.pow(1 + interest, period))) / ((Math.pow(1 + interest, period)) - 1);
		return emi;
	}

	public List<Transactions> printTransactions(int transId) {
		return dao.printTransactions(transId);
	}

	// validations
	public boolean isValidateName(String custName) {
		String pattern = "[A-Za-z]{4,}";
		return custName.matches(pattern);
	}

}
