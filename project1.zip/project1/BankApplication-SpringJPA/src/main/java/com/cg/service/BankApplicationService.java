package com.cg.service;

import java.util.List;

import com.cg.entity.BankApplication;
import com.cg.entity.Transactions;

public interface BankApplicationService {

	public int saveLoan(BankApplication loan);

	public BankApplication showBalance(int transId);

	public double payEmi(int transId);

	public void foreClose(int transId);

	public double calculateEmi(BankApplication loan);

	public List<Transactions> printTransactions(int transId);
}
