package com.cg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ln")
public class BankApplication {

	@Id
	private int transId;
	@Column(name = "acntNo")
	private int acntNo;
	@Column(name = "Name", length = 15)
	private String name;
	@Column(name = "Amount", length = 15)
	private double loanAmount;
	@Column(name = "period")
	private int period;
	@Column(name = "Rate", length = 15)
	private double rate;
	@Column(name = "Balance", length = 15)
	private double balance;
	@Column(name = "EMI", length = 15)
	private double emi;

	public BankApplication() {

	}

	public BankApplication(int acntNo, String name, double loanAmount, int period, double rate) {
		this.acntNo = acntNo;
		this.name = name;
		this.loanAmount = loanAmount;
		this.period = period;
		this.rate = rate;

	}

	public int getAcntNo() {
		return acntNo;
	}

	public void setAcntNo(int acntNo) {
		this.acntNo = acntNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public int getPeriod() {
		return period;
	}

	public double getLoanAmount() {
		return loanAmount;
	}

	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}

	public void setPeriod(int period) {
		this.period = period;
	}

	public double getRate() {
		return rate;
	}

	public void setRate(double rate) {
		this.rate = rate;
	}

	public double getEmi() {
		return emi;
	}

	public void setEmi(double emi) {
		this.emi = emi;
	}

	public int getTransId() {
		return transId;
	}

	public void setTransId(int transId) {
		this.transId = transId;
	}

	@Override
	public String toString() {
		return "LoanApplication [loanAmount=" + loanAmount + ", balance=" + balance + ", emi=" + emi + "]";
	}

}
